# Task: 15 V sensor node

## Problem report

The first boards built from these files fail bring-up. Observations so far:

- Bench: U2.VDD reads 14.85 V, expected 2.425 V to 2.575 V (`mcu_vdd`).
- Bench: U2.NRST reads 14.85 V, expected 2.25 V to 2.6 V (`nrst_high`).
- Bench: current through R5 is 6.567 mA, expected 0 A to 3 mA (`sda_sink_current`).
- Bench: current through R6 is 6.567 mA, expected 0 A to 3 mA (`scl_sink_current`).
- Bench: current through D3 is 42.38 mA, expected 1.742 mA to 2.356 mA (`power_led_current`).
- Bench: J2.1 reads 14.83 V, expected 2.425 V to 2.575 V (`2v5_rail`).
- Bench: J2.1 reads 3.42 V, expected 2.425 V to 2.575 V (`2v5_rail_low_vin`).
- Schematic ERC reports 1× unconnected_required.
- The fab's DRC run reports 1 unconnected item(s).

Fix every problem (there may be more than the observations show directly).

## Design intent

# 15 V sensor node

A sensor node board. Power enters on J1 at +15 V; LDO U1 makes the +2V5 rail
(2.5 V) for MCU U2, the I2C bus pull-ups and the I2C bus header J2 (which also powers the
off-board sensors). The MCU reads an external voltage through a scaled, filtered divider on an ADC
pin and shows its state on a status LED.

Rails: +15 V (from J1) -> reverse-polarity diode -> VIN -> U1 -> +2V5 = 2.5 V.

## Connectors

| Connector | Pin | Signal |
|---|---|---|
| J1 | 1 | +15 V input |
| J1 | 2 | GND |
| J2 | 1 | +2V5 (bus supply) |
| J2 | 2 | GND |
| J2 | 3 | SDA |
| J2 | 4 | SCL |
| J3 | 1 | external voltage input, 0–5 V |
| J3 | 2 | GND |

## MCU pin assignment (firmware-fixed)

| MCU pin | Function |
|---|---|
| VDD | supply, +2V5 rail |
| GND | ground |
| NRST | reset input, held high (no internal pull-up) |
| SDA | I2C data -> J2 pin 3 |
| SCL | I2C clock -> J2 pin 4 |
| PA0 | status LED drive (push-pull, high = on) |
| PA1 | ADC input: external voltage (scaled so 5 V reads 90 % of full scale) |

## Circuit

- Reverse-polarity protection: Schottky D1 in series with the input, anode to J1 pin 1, cathode to the protected input rail VIN; C1 is a bulk capacitor on VIN.
- U1 (LDO_ADJ) regulates the 15 V input down to the 2.5 V rail +2V5: C2 is its input capacitor (VIN to GND) and C3 its output capacitor (VOUT to GND), each at its pin; R1 from VOUT to FB and R2 from FB to GND set VOUT = 0.8 V x (1 + R1/R2); EN is pulled up to the input through R3.
- U2 (MCU8) runs from +2V5; C4 decouples VDD at the pin; R4 pulls NRST up to +2V5.
- I2C: SDA (U2.SDA -> J2.3) and SCL (U2.SCL -> J2.4) are open-drain with pull-ups R5 (SDA) and R6 (SCL) to +2V5; J2 pin 1 supplies +2V5 to the off-board devices.
- PA0 drives the status LED D2 through R7 (U2.PA0 -> R7 -> D2 anode, cathode to GND).
- External voltage input: R8 from J3 pin 1 to the ADC node, R9 from the ADC node to GND, C5 from the ADC node to GND (anti-alias); the ADC node goes to U2.PA1.
- power indicator: R10 from +2V5 to the anode of D3, cathode to GND.

## Spec

MCU supply 2.5 V ±3 % at its VDD/GND pins; NRST ≥ 0.9·VDD.

I2C standard-mode, up to 400 pF off-board capacitance per line (+5 pF pin): rise time (30–70 % of VDD, UM10204) ≤ 1000 ns; pull-up current ≤ 3 mA at VOL = 0.4 V.

Status LED current 5.02 mA ±15 % with PA0 high.

External voltage: U2.PA1 = 0.4500 × input ±2 % (5 V -> 2.25 V); anti-alias -3 dB corner 520 Hz ±10 %.

Power indicator current 2.05 mA ±15 %.

Rail +2V5: 2.5 V ±3 % with 5 mA drawn by the off-board I2C devices from J2 pin 1, for inputs from 3.5 V to 15 V.

Component values: input bulk capacitor C1 1 µF–22 µF; C2, C3 1 µF–22 µF (LDO datasheet); feedback Rbot R2 3.3 kΩ–150 kΩ (10k–50k typical) with R1 scaled to match; EN pull-up R3 keeps EN above 1.2 V at the lowest input; MCU decoupling C4 47 nF–10 µF (100 nF typical); NRST pull-up R4 2.2 kΩ–100 kΩ; I2C pull-ups R5, R6 within the datasheet range (VDD-0.4 V)/3 mA .. tr/(0.8473·Cbus) that meets the spec.

Sub-circuits by purpose: input reverse-polarity protection and bulk capacitor (D1, C1); 2.5 V regulator with input/output capacitors and feedback divider (U1, C2, C3, R1, R2, R3); MCU with VDD decoupling and reset pull-up (U2, C4, R4); I2C bus pull-ups and bus header (R5, R6, J2); status LED with series resistor (D2, R7); external voltage scaling divider with anti-alias capacitor (R8, R9, C5); external voltage input connector (J3); power indicator LED with series resistor (D3, R10).

## Spec assertions

The design must satisfy these assertions (`pcbtool sim` runs them; full definitions in `spec.json`):

- `mcu_vdd`: DC voltage at U2.VDD relative to U2.GND between 2.425 V and 2.575 V (J1.1 supplied with 15.0 V; ground = J1.2)
- `nrst_high`: DC voltage at U2.NRST between 2.25 V and 2.6 V (J1.1 supplied with 15.0 V; ground = J1.2)
- `sda_rise_time`: 30-70 % transition time at U2.SDA between 0 s and 1 us (J1.1 supplied with 15.0 V; open-drain driver releasing the line on U2.SDA; load C=4e-10 from J2.3 to ground; load C=4e-10 from J2.4 to ground; ground = J1.2)
- `sda_sink_current`: DC current through R5 between 0 A and 3 mA (J1.1 supplied with 15.0 V; 0.4 V DC source on U2.SDA; ground = J1.2)
- `scl_rise_time`: 30-70 % transition time at U2.SCL between 0 s and 1 us (J1.1 supplied with 15.0 V; open-drain driver releasing the line on U2.SCL; load C=4e-10 from J2.3 to ground; load C=4e-10 from J2.4 to ground; ground = J1.2)
- `scl_sink_current`: DC current through R6 between 0 A and 3 mA (J1.1 supplied with 15.0 V; 0.4 V DC source on U2.SCL; ground = J1.2)
- `status_led_current`: DC current through D2 between 4.268 mA and 5.775 mA (J1.1 supplied with 15.0 V; 2.5168 V DC source on U2.PA0; ground = J1.2)
- `external voltage_full_scale`: DC voltage at U2.PA1 between 2.205 V and 2.295 V (J1.1 supplied with 15.0 V; 5.0 V DC source on J3.1; ground = J1.2)
- `external voltage_half_scale`: DC voltage at U2.PA1 between 1.103 V and 1.147 V (J1.1 supplied with 15.0 V; 2.5 V DC source on J3.1; ground = J1.2)
- `external voltage_anti_alias_corner`: -3 dB frequency from J3.1 to U2.PA1 between 468 Hz and 571.9 Hz (J1.1 supplied with 15.0 V; 1.0 V AC source on J3.1; ground = J1.2)
- `power_led_current`: DC current through D3 between 1.742 mA and 2.356 mA (J1.1 supplied with 15.0 V; ground = J1.2)
- `2v5_rail`: DC voltage at J2.1 between 2.425 V and 2.575 V (J1.1 supplied with 15.0 V; load R=500 from J2.1 to ground; ground = J1.2)
- `2v5_rail_low_vin`: DC voltage at J2.1 between 2.425 V and 2.575 V (J1.1 supplied with 3.5 V; load R=500 from J2.1 to ground; ground = J1.2)

Layout: every track of these nets must be at least the given width:

- +2V5 (the net of J2.1): ≥ 0.3 mm
- GND (the net of J1.2): ≥ 0.3 mm
- VIN (the net of C1.1): ≥ 0.3 mm
- VIN_RAW (the net of J1.1): ≥ 0.3 mm

Component values: each value must lie in its acceptable range (inclusive; `value_bounds` in `spec.json`). Ranges come from the datasheets and the design intent; values the assertions already pin down get a wide sanity range, and the assertions still apply:

- C1 (C): 1 uF … 22 uF
- C2 (C): 1 uF … 22 uF
- C3 (C): 1 uF … 22 uF
- C4 (C): 47 nF … 10 uF
- C5 (C): 2.2 nF … 23 nF
- R1 (R): 7 kΩ … 320 kΩ
- R10 (R): 17 Ω … 870 Ω
- R2 (R): 3.3 kΩ … 150 kΩ
- R3 (R): 1 Ω … 3.9 MΩ
- R4 (R): 2.2 kΩ … 100 kΩ
- R5 (R): 700 Ω … 8.4 kΩ
- R6 (R): 700 Ω … 5.8 kΩ
- R7 (R): 20 Ω … 230 Ω
- R8 (R): 22 kΩ … 220 kΩ
- R9 (R): 17 kΩ … 230 kΩ

Board rules: 2 copper layers, clearance 0.2 mm, min track 0.2 mm, vias 0.6/0.3 mm, copper-to-edge 0.3 mm. DRC must be clean with no unconnected items.

## Design rules (design review)

Besides the spec, the design must pass an engineering design review. **`pcbtool` does not check any
of this — review the design yourself** against the datasheets in `parts/` (see each part's ratings /
design-rule section) and the design intent:

- **Absolute maximum ratings** of every part under every operating condition of the spec (no MCU pin
  above its VDD + 0.3 V or below -0.3 V, op-amp inputs within the rails, LDO EN ≤ VIN, MOSFET |VGS|,
  transistor / diode voltage and current limits).
- **Current limits:** MCU pin currents, LED forward current (by LED package), transistor collector /
  base currents; a saturated NPN switch needs a forced beta IC/IB ≤ 20.
- **Power / voltage ratings:** every resistor's I²R ≤ 50 % of its footprint's rating; every capacitor's
  working voltage ≤ 80 % of its footprint's rated voltage. Footprint choice matters.
- **Inductive loads** have a flyback diode directly across the load, cathode to the supply side.
- **Interfaces and pin assignments** stated in the design intent (connector pinouts, MCU pin functions,
  which rail each part connects to) must be respected exactly, even where the circuit would still
  simulate with a different assignment.

The grader checks these rules under the spec's operating conditions. A design can pass every
`pcbtool` check and still fail review.

**Decoupling** (graded as part of `layout`; `pcbtool` does not check it, `spec.json` lists it under `design_rules`): each capacitor's pad on the IC pin's net must reach that pin within the given length of copper path (shortest path along the net's tracks, vias and pads, pad centre to pad centre), and every pad of the capacitor must lie within the given straight-line distance of the pin:

- C2 within 8.0 mm of copper path of U1.VIN (and within 5.0 mm straight-line)
- C3 within 8.0 mm of copper path of U1.VOUT (and within 5.0 mm straight-line)
- C4 within 8.0 mm of copper path of U2.VDD (and within 5.0 mm straight-line)

## Deliverable

- Edit only `design.json` (the schematic of record) and `board.kicad_pcb` (the layout).
- Do not add, remove or rename components; keep each component's part.
- Keep the two files consistent: same connectivity, values and footprints on both.
- Values: `<number><SI prefix><unit>` such as `4.7k`, `100n`, `10kΩ`, `1meg`; unit letters, if any, must match the part (R: Ω/ohm/R, C: F, L: H, crystal: Hz); no spaces or control characters inside (full grammar: "Value notation" in `parts/R.md`, `parts/C.md`, ...).
- Do not change the board outline, add zones, or add DRC exclusions.
- Footprints must be unmodified library footprints from the part's allowed list (see `parts/<PART>.md`).
- Grading is pass/fail: topology, consistency, DRC, ERC, spec, component values, layout and the design rules above must all pass.

## Tools

Run `pcbtool <command>` inside this directory (you may also edit the two files directly).

Read-only:
- `pcbtool show` — components, values, footprints, positions and nets
- `pcbtool netlist` — design nets vs. board pad nets, with differences highlighted
- `pcbtool drc` — KiCad DRC under the canonical rules (the same rules the grader uses)
- `pcbtool erc` — electrical rule check of design.json
- `pcbtool sim` — run the spec assertions (spec.json) on design.json
- `pcbtool parts [PART]` — list parts / print a part's datasheet (also in `parts/`)
- `pcbtool check` — all of the above in one summary

Mutating (each keeps design.json and board.kicad_pcb consistent and saves both):
- `pcbtool set-value REF VALUE`
- `pcbtool set-footprint REF LIB:FOOTPRINT`
- `pcbtool connect REF.PIN NET` / `pcbtool disconnect REF.PIN`
- `pcbtool move REF X Y ROT` (absolute mm, degrees; tracks do not follow)
- `pcbtool unroute NET` / `pcbtool route NET [--width W]` (re-routes the whole net)
- `pcbtool sync` — push design.json connectivity and values onto the board pads

**Tool mode for this task: `no_autoroute`** (`tools.json`). `pcbtool route` and `pcbtool sync` are
disabled: after changing connectivity or footprints, edit the tracks (`segment` / `via` items) in
`board.kicad_pcb` yourself, or move parts with `pcbtool move`. All other commands work.
