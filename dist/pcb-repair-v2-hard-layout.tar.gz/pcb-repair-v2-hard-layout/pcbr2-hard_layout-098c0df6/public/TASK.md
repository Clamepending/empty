# Task: 12 V DC motor controller

## Problem report

The first boards built from these files fail bring-up. Observations so far:

- Bench: U2.VDD reads 12 V, expected 4.85 V to 5.15 V (`mcu_vdd`).
- Bench: U2.NRST reads 12 V, expected 4.5 V to 5.2 V (`nrst_high`).
- Bench: current through R9 is 5.269 mA, expected 0 A to 3 mA (`sda_sink_current`).
- Bench: current through R10 is 5.269 mA, expected 0 A to 3 mA (`scl_sink_current`).
- Bench: current through D2 is 14.81 mA, expected 3.551 mA to 4.804 mA (`fault_led_current`).
- Bench: J3.1 reads 11.99 V, expected 4.85 V to 5.15 V (`5v_rail`).
- Bench: J3.1 reads 5.593 V, expected 4.85 V to 5.15 V (`5v_rail_low_vin`).

Fix every problem (there may be more than the observations show directly).

## Design intent

# 12 V DC motor controller

Drives a brushed DC motor (J2) from the +12 V supply on J1 with a low-side MOSFET under
PWM control of MCU U2, measures the motor current through a shunt on an ADC pin, reports over I2C
(header J3) and shows a fault LED. LDO U1 makes the +5V logic rail (5 V) from the
motor supply.

Rails: +12 V (from J1: motor, LDO input) -> U1 -> +5V = 5 V (MCU, I2C, LEDs).

## Connectors

| Connector | Pin | Signal |
|---|---|---|
| J1 | 1 | +12 V motor / board supply input |
| J1 | 2 | GND |
| J2 | 1 | motor + (+12 V) |
| J2 | 2 | motor - (switched return) |
| J3 | 1 | +5V (bus supply) |
| J3 | 2 | GND |
| J3 | 3 | SDA |
| J3 | 4 | SCL |

## MCU pin assignment (firmware-fixed)

| MCU pin | Function |
|---|---|
| VDD | supply, +5V rail |
| GND | ground |
| NRST | reset input, held high (no internal pull-up) |
| PA0 | PWM motor drive (high = motor on) |
| PA1 | ADC input: motor current sense, V = I x 0.22 Ω |
| SDA | I2C data -> J3 pin 3 |
| SCL | I2C clock -> J3 pin 4 |
| PA2 | fault LED drive (push-pull, high = on) |

## Circuit

- U1 (LDO_ADJ) regulates the 12 V input down to the 5 V rail +5V: C1 is its input capacitor (VIN to GND) and C2 its output capacitor (VOUT to GND), each at its pin; R1 from VOUT to FB and R2 from FB to GND set VOUT = 0.8 V x (1 + R1/R2); EN is pulled up to the input through R3.
- U2 (MCU8) runs from +5V; C3 decouples VDD at the pin; R4 pulls NRST up to +5V.
- Motor switch: logic-level NMOS Q1 with its source on the sense node ISENSE and its drain on the switched motor return (J2 pin 2); PA0 drives the gate through R5 and R6 pulls the gate to GND so the motor is off while the MCU is in reset; Schottky D1 clamps the motor's inductive kick: cathode to J2 pin 1 (+12 V), anode to J2 pin 2; C5 is the bulk capacitor across the motor supply.
- Current sense: shunt R7 from ISENSE to GND; R8 from ISENSE to U2.PA1 with C4 from U2.PA1 to GND filters the sense voltage.
- I2C: SDA (U2.SDA -> J3.3) and SCL (U2.SCL -> J3.4) are open-drain with pull-ups R9 (SDA) and R10 (SCL) to +5V; J3 pin 1 supplies +5V to the off-board devices.
- PA2 drives the fault LED D2 through R11 (U2.PA2 -> R11 -> D2 anode, cathode to GND).

## Spec

MCU supply 5 V ±3 % at its VDD/GND pins; NRST ≥ 0.9·VDD.

Motor (~15.63 Ω, 5 mH): PA0 high -> 0.75 A ±5 % with VDS ≤ 0.3 V and gate-drive current ≤ 1 mA; PA0 floating -> motor off (< 0.1 mA) even with 10 MΩ leakage from +12 V to the gate.

Current sense: U2.PA1 reads 165 mV ±7 % at 0.75 A; sense filter -3 dB corner 94.06 Hz ±10 %.

Motor-current traces (+12V, motor return, ISENSE, GND) at least 0.5 mm wide.

I2C standard-mode, up to 300 pF off-board capacitance per line (+5 pF pin): rise time (30–70 % of VDD, UM10204) ≤ 1000 ns; pull-up current ≤ 3 mA at VOL = 0.4 V.

Fault LED current 4.18 mA ±15 % with PA2 high.

Rail +5V: 5 V ±3 % with 5 mA drawn by the telemetry host interface from J3 pin 1, for inputs from 5.6 V to 12 V.

Component values: C1, C2 1 µF–22 µF (LDO datasheet); feedback Rbot R2 3.3 kΩ–150 kΩ (10k–50k typical) with R1 scaled to match; EN pull-up R3 keeps EN above 1.2 V at the lowest input; MCU decoupling C3 47 nF–10 µF (100 nF typical); NRST pull-up R4 2.2 kΩ–100 kΩ; gate series resistor R5 4.7 Ω–220 Ω (datasheet: 10–100 Ω); gate pull-down R6 4.7 kΩ–220 kΩ (datasheet: 10k–100k); motor-supply bulk capacitor C5 1 µF–22 µF; I2C pull-ups R9, R10 within the datasheet range (VDD-0.4 V)/3 mA .. tr/(0.8473·Cbus) that meets the spec.

Sub-circuits by purpose: 5 V regulator with input/output capacitors and feedback divider (U1, C1, C2, R1, R2, R3); MCU with VDD decoupling and reset pull-up (U2, C3, R4); motor switch: MOSFET, gate resistor and gate pull-down (Q1, R5, R6); motor connector, flyback diode and motor-supply bulk capacitor (J2, D1, C5); current-sense shunt and RC filter into the ADC (R7, R8, C4); I2C bus pull-ups and bus header (R9, R10, J3); fault LED with series resistor (D2, R11).

## Spec

The design must satisfy these assertions (`pcbtool sim` runs them; full definitions in `spec.json`):

- `mcu_vdd`: DC voltage at U2.VDD relative to U2.GND between 4.85 V and 5.15 V (J1.1 supplied with 12.0 V; ground = J1.2)
- `nrst_high`: DC voltage at U2.NRST between 4.5 V and 5.2 V (J1.1 supplied with 12.0 V; ground = J1.2)
- `motor_on_current`: DC current through J2.2 between 712.5 mA and 787.5 mA (J1.1 supplied with 12.0 V; 4.9925 V DC source on U2.PA0; load R=15.63 L=0.005 from J2.1 to J2.2; ground = J1.2)
- `vds_on`: DC voltage at Q1.D relative to Q1.S between 0 V and 300 mV (J1.1 supplied with 12.0 V; 4.9925 V DC source on U2.PA0; load R=15.63 L=0.005 from J2.1 to J2.2; ground = J1.2)
- `motor_off_current`: DC current through J2.2 between 0 A and 100 uA (J1.1 supplied with 12.0 V; load R=15.63 L=0.005 from J2.1 to J2.2; load R=1e+07 from Q1.G to J1.1; ground = J1.2)
- `gate_drive_current`: DC current through R5 between 0 A and 1 mA (J1.1 supplied with 12.0 V; 4.9925 V DC source on U2.PA0; load R=15.63 L=0.005 from J2.1 to J2.2; ground = J1.2)
- `current_sense_voltage`: DC voltage at U2.PA1 between 153.4 mV and 176.6 mV (J1.1 supplied with 12.0 V; 4.9925 V DC source on U2.PA0; load R=15.63 L=0.005 from J2.1 to J2.2; ground = J1.2)
- `current_sense_corner`: -3 dB frequency from R7.1 to U2.PA1 between 84.66 Hz and 103.5 Hz (J1.1 supplied with 12.0 V; 1.0 V AC source on R7.1; ground = J1.2)
- `sda_rise_time`: 30-70 % transition time at U2.SDA between 0 s and 1 us (J1.1 supplied with 12.0 V; open-drain driver releasing the line on U2.SDA; load C=3e-10 from J3.3 to ground; load C=3e-10 from J3.4 to ground; ground = J1.2)
- `sda_sink_current`: DC current through R9 between 0 A and 3 mA (J1.1 supplied with 12.0 V; 0.4 V DC source on U2.SDA; ground = J1.2)
- `scl_rise_time`: 30-70 % transition time at U2.SCL between 0 s and 1 us (J1.1 supplied with 12.0 V; open-drain driver releasing the line on U2.SCL; load C=3e-10 from J3.3 to ground; load C=3e-10 from J3.4 to ground; ground = J1.2)
- `scl_sink_current`: DC current through R10 between 0 A and 3 mA (J1.1 supplied with 12.0 V; 0.4 V DC source on U2.SCL; ground = J1.2)
- `fault_led_current`: DC current through D2 between 3.551 mA and 4.804 mA (J1.1 supplied with 12.0 V; 4.9925 V DC source on U2.PA2; ground = J1.2)
- `5v_rail`: DC voltage at J3.1 between 4.85 V and 5.15 V (J1.1 supplied with 12.0 V; load R=1000 from J3.1 to ground; ground = J1.2)
- `5v_rail_low_vin`: DC voltage at J3.1 between 4.85 V and 5.15 V (J1.1 supplied with 5.6 V; load R=1000 from J3.1 to ground; ground = J1.2)

Layout: every track of these nets must be at least the given width:

- +12V (the net of J1.1): ≥ 0.5 mm
- +5V (the net of J3.1): ≥ 0.3 mm
- GND (the net of J1.2): ≥ 0.5 mm
- ISENSE (the net of Q1.S): ≥ 0.5 mm
- MOTOR_SW (the net of J2.2): ≥ 0.5 mm

Component values: each value must lie in its acceptable range (inclusive; `value_bounds` in `spec.json`). Ranges come from the datasheets and the design intent; values the assertions already pin down get a wide sanity range, and the assertions still apply:

- C1 (C): 1 uF … 22 uF
- C2 (C): 1 uF … 22 uF
- C3 (C): 47 nF … 10 uF
- C4 (C): 170 nF … 1.8 uF
- C5 (C): 1 uF … 22 uF
- R1 (R): 17 kΩ … 790 kΩ
- R10 (R): 560 Ω … 8.4 kΩ
- R11 (R): 230 Ω … 2 kΩ
- R2 (R): 3.3 kΩ … 150 kΩ
- R3 (R): 1 Ω … 7.4 MΩ
- R4 (R): 2.2 kΩ … 100 kΩ
- R5 (R): 4.7 Ω … 220 Ω
- R6 (R): 4.7 kΩ … 220 kΩ
- R7 (R): 63 mΩ … 570 mΩ
- R8 (R): 970 Ω … 14 kΩ
- R9 (R): 620 Ω … 7 kΩ

Board rules: 2 copper layers, clearance 0.2 mm, min track 0.2 mm, vias 0.6/0.3 mm, copper-to-edge 0.3 mm. DRC must be clean with no unconnected items.

## Design rules (design review)

Besides the spec, the design must pass an engineering design review. **`pcbtool` does not check any
of this — review the design yourself** against the datasheets in `parts/` (see each part's ratings /
design-rule section) and the design intent:

- **Absolute maximum ratings** of every part under every operating condition of the spec (no MCU pin
  above its VDD + 0.3 V or below -0.3 V, op-amp inputs within the rails, LDO EN ≤ VIN, MOSFET |VGS|,
  transistor / diode voltage and current limits).
- **Current limits:** MCU pin currents, LED forward current (by LED package), transistor collector /
  base currents; a saturated NPN switch needs a forced beta IC/IB ≤ 20.
- **Power / voltage ratings:** every resistor's I²R ≤ 50 % of its footprint's rating; every capacitor's
  working voltage ≤ 80 % of its footprint's rated voltage. Footprint choice matters.
- **Inductive loads** have a flyback diode directly across the load, cathode to the supply side.
- **Interfaces and pin assignments** stated in the design intent (connector pinouts, MCU pin functions,
  which rail each part connects to) must be respected exactly, even where the circuit would still
  simulate with a different assignment.

The grader checks these rules under the spec's operating conditions. A design can pass every
`pcbtool` check and still fail review.

**Decoupling** (graded as part of `layout`; `pcbtool` does not check it, `spec.json` lists it under `design_rules`): each capacitor's pad on the IC pin's net must reach that pin within the given length of copper path (shortest path along the net's tracks, vias and pads, pad centre to pad centre), and every pad of the capacitor must lie within the given straight-line distance of the pin:

- C1 within 8.0 mm of copper path of U1.VIN (and within 5.0 mm straight-line)
- C2 within 8.0 mm of copper path of U1.VOUT (and within 5.0 mm straight-line)
- C3 within 8.0 mm of copper path of U2.VDD (and within 5.0 mm straight-line)

## Layout rules (board geometry)

The board must also follow these layout rules. **`pcbtool` does not check any of them** (not `check`, not `drc`, not `show`) -- they are graded from the geometry in `board.kicad_pcb`; `spec.json` lists the same rules under `layout_rules` with their pins and limits. All lengths in mm, KiCad board coordinates (y grows downwards). Definitions used below:

- *Pad centre*: the pad's absolute position (footprint `(at x y rot)` plus the pad's `(at ...)` offset rotated by the footprint orientation; KiCad Python: `pad.GetPosition()`).
- *Copper path* from pad A to pad B: the shortest route along the net's copper -- track centrelines (each `segment` from start to end), vias (joining F.Cu and B.Cu at their centre) and pads (a pad joins every track point that lies inside it) -- measured from A's centre to B's centre. Tracks connect where their copper touches (same layer). As a polyline it runs through A's centre, the track end / junction points it follows, and B's centre.
- *Touch*: two copper items of a net touch when their copper overlaps or abuts (a track is its centreline swept by half its width, a via a disc of its diameter, a pad its outline).

**Kelvin sense connection** (current shunt R7): the ADC sense connection R8.1 must leave from the shunt pad R7.1 itself, on its own trace -- not from a point on the load-current path. Check: delete pad R7.1; the copper island (items of the net that touch, transitively) holding pad R8.1 must not contain pad Q1.S (the load current's pin). So the sense trace and the load-current copper may meet only through the shunt pad, never by touching each other (not even inside the pad). The power-net width rule still applies to the sense trace (it is on the same net).

**Switching loop area** (motor switch commutation loop): the loop through the bulk capacitor, the flyback diode, the switch and the shunt is the polygon made of the copper paths C5.1 -> D1.K, D1.A -> Q1.D, Q1.S -> R7.1, R7.2 -> C5.2 (each as a polyline, see above), joined by straight lines across each part from one leg's end pad to the next leg's start pad (D1.K -> D1.A, Q1.D -> Q1.S, R7.1 -> R7.2, C5.2 -> C5.1). Its area A = ½·|Σ (x_i·y_(i+1) − x_(i+1)·y_i)| over the polygon's vertices (shoelace formula) must be ≤ 60 mm². (If the polygon crosses itself, A is the area it encloses with every region counted |winding number| times, so lobes never cancel; the grader evaluates that case on a 0.02 mm grid.) Keep these parts tight together and route the legs directly.

**Analog / switching separation**: the analog net (the net of U2.PA1, the ADC input) must not run alongside the switching node (the net of Q1.D). For tracks on the same copper layer, the total length of analog-net track centreline that lies within 1 mm (centreline to centreline) of any switching-node track centreline must be ≤ 3 mm (crossings on opposite layers do not count).

**Decoupling** (as stated under Design rules: copper path cap pad -> IC pin, plus straight-line distance) is part of the same layout review.

Grading: the `layout_rules` check fails if any rule above is violated; the decoupling rule is graded by the `layout` check. `pcbtool route` knows nothing about these rules (it joins a net's pads as a shortest tree, which can itself violate them); review and, if needed, hand-edit the tracks.

## Deliverable

- Edit only `design.json` (the schematic of record) and `board.kicad_pcb` (the layout).
- Do not add, remove or rename components; keep each component's part.
- Keep the two files consistent: same connectivity, values and footprints on both.
- Values: `<number><SI prefix><unit>` such as `4.7k`, `100n`, `10kΩ`, `1meg`; unit letters, if any, must match the part (R: Ω/ohm/R, C: F, L: H, crystal: Hz); no spaces or control characters inside (full grammar: "Value notation" in `parts/R.md`, `parts/C.md`, ...).
- Do not change the board outline, add zones, or add DRC exclusions.
- Footprints must be unmodified library footprints from the part's allowed list (see `parts/<PART>.md`).
- Grading is pass/fail: topology, consistency, DRC, ERC, spec, component values, layout, the design rules and the layout rules above must all pass.

## Tools

Run `pcbtool <command>` inside this directory (you may also edit the two files directly).

Read-only:
- `pcbtool show` — components, values, footprints, positions and nets
- `pcbtool netlist` — design nets vs. board pad nets, with differences highlighted
- `pcbtool drc` — KiCad DRC under the canonical rules (the same rules the grader uses)
- `pcbtool erc` — electrical rule check of design.json
- `pcbtool sim` — run the spec assertions (spec.json) on design.json
- `pcbtool parts [PART]` — list parts / print a part's datasheet (also in `parts/`)
- `pcbtool check` — all of the above in one summary

Mutating (each keeps design.json and board.kicad_pcb consistent and saves both):
- `pcbtool set-value REF VALUE`
- `pcbtool set-footprint REF LIB:FOOTPRINT`
- `pcbtool connect REF.PIN NET` / `pcbtool disconnect REF.PIN`
- `pcbtool move REF X Y ROT` (absolute mm, degrees; tracks do not follow)
- `pcbtool unroute NET` / `pcbtool route NET [--width W]` (re-routes the whole net)
- `pcbtool sync` — push design.json connectivity and values onto the board pads

**Tool mode for this task: `no_autoroute`** (`tools.json`). `pcbtool route` and `pcbtool sync` are
disabled: after changing connectivity or footprints, edit the tracks (`segment` / `via` items) in
`board.kicad_pcb` yourself, or move parts with `pcbtool move`. All other commands work.
