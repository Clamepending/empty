# Task: 4-channel LED indicator board

## Problem report

The first boards built from these files fail bring-up. Observations so far:

- LED D1 never lights (`string1_current`: 2.57 uA; expected 1.8 mA to 2.2 mA).
- Bench: current through D3 is 544.3 uA, expected 4.5 mA to 5.5 mA (`string3_current`).
- Incoming inspection: a part value on the layout does not match the design.json BOM.

A reviewer narrowed the failure down to these areas (each needs a fix):

- the value of R1
- the value of R3
- the value of R2 on the board vs. design.json

Fix every problem (there may be more than the observations show directly).

## Design intent

# 4-channel LED indicator board

Lights 4 indicator LEDs from a 3.3 V supply on J1
(pin 1 = +3.3 V, pin 2 = GND). Each channel is a series string of LEDs fed through its own
current-limiting resistor; the resistor sets the current from (Vs - n*Vf)/R.

- Channel 1: 1 red LED(s) at 2 mA: supply -> R1 -> D1 (anode to cathode) -> GND.
- Channel 2: 1 green LED(s) at 5 mA: supply -> R2 -> D2 (anode to cathode) -> GND.
- Channel 3: 1 red LED(s) at 5 mA: supply -> R3 -> D3 (anode to cathode) -> GND.
- Channel 4: 1 green LED(s) at 2 mA: supply -> R4 -> D4 (anode to cathode) -> GND.

Spec: each channel's LED current within ±10 % of its target. Resistors dissipating more than
~60 mW use a 1206 footprint.

## Spec

The design must satisfy these assertions (`pcbtool sim` runs them; full definitions in `spec.json`):

- `string1_current`: DC current through D1 between 1.8 mA and 2.2 mA (J1.1 supplied with 3.3 V; ground = J1.2)
- `string2_current`: DC current through D2 between 4.5 mA and 5.5 mA (J1.1 supplied with 3.3 V; ground = J1.2)
- `string3_current`: DC current through D3 between 4.5 mA and 5.5 mA (J1.1 supplied with 3.3 V; ground = J1.2)
- `string4_current`: DC current through D4 between 1.8 mA and 2.2 mA (J1.1 supplied with 3.3 V; ground = J1.2)

Layout: every track of these nets must be at least the given width:

- +3V3 (the net of J1.1): ≥ 0.3 mm
- GND (the net of J1.2): ≥ 0.3 mm

Component values: each value must lie in its acceptable range (inclusive; `value_bounds` in `spec.json`). Ranges come from the datasheets and the design intent; values the assertions already pin down get a wide sanity range, and the assertions still apply:

- R1 (R): 190 Ω … 2.3 kΩ
- R2 (R): 56 Ω … 830 Ω
- R3 (R): 71 Ω … 830 Ω
- R4 (R): 220 Ω … 2.2 kΩ

Board rules: 2 copper layers, clearance 0.2 mm, min track 0.2 mm, vias 0.6/0.3 mm, copper-to-edge 0.3 mm. DRC must be clean with no unconnected items.

## Deliverable

- Edit only `design.json` (the schematic of record) and `board.kicad_pcb` (the layout).
- Do not add, remove or rename components; keep each component's part.
- Keep the two files consistent: same connectivity, values and footprints on both.
- Do not change the board outline, add zones, or add DRC exclusions.
- Footprints must be unmodified library footprints from the part's allowed list (see `parts/<PART>.md`).
- Grading is pass/fail: topology, consistency, DRC, ERC, spec, component values and layout must all pass.

## Tools

Run `pcbtool <command>` inside this directory (you may also edit the two files directly).

Read-only:
- `pcbtool show` — components, values, footprints, positions and nets
- `pcbtool netlist` — design nets vs. board pad nets, with differences highlighted
- `pcbtool drc` — KiCad DRC under the canonical rules (the same rules the grader uses)
- `pcbtool erc` — electrical rule check of design.json
- `pcbtool sim` — run the spec assertions (spec.json) on design.json
- `pcbtool parts [PART]` — list parts / print a part's datasheet (also in `parts/`)
- `pcbtool check` — all of the above in one summary

Mutating (each keeps design.json and board.kicad_pcb consistent and saves both):
- `pcbtool set-value REF VALUE`
- `pcbtool set-footprint REF LIB:FOOTPRINT`
- `pcbtool connect REF.PIN NET` / `pcbtool disconnect REF.PIN`
- `pcbtool move REF X Y ROT` (absolute mm, degrees; tracks do not follow)
- `pcbtool unroute NET` / `pcbtool route NET [--width W]` (re-routes the whole net)
- `pcbtool sync` — push design.json connectivity and values onto the board pads
