# R — resistor

Two-terminal resistor. Pins `1`, `2` (non-polarised). Value in ohms.
