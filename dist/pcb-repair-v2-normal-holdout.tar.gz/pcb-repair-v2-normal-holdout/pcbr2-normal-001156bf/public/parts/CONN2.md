# CONN2 — 2-pin header

Pin `1` = signal/supply, pin `2` = ground by board convention.
